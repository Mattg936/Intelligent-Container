<?php

namespace contenedor\Events;

abstract class Event
{
    //
}
