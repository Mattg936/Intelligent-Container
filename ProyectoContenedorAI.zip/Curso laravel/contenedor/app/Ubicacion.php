<?php

namespace contenedor;

use Illuminate\Database\Eloquent\Model;

class Ubicacion extends Model
{
    //
}
