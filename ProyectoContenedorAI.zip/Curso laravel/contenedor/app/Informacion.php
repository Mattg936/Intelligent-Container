<?php

namespace contenedor;

use Illuminate\Database\Eloquent\Model;

class Informacion extends Model
{

}
